package org.web3j.abi.datatypes.generated;

import org.web3j.abi.datatypes.Bytes;

/**
 * <p>Auto generated code.<br>
 * <strong>Do not modifiy!</strong><br>
 * Please use {@link org.web3j.codegen.AbiTypesGenerator} to update.</p>
 */
public class Bytes17 extends Bytes {
  public static final Bytes17 DEFAULT = new Bytes17(new byte[17]);

  public Bytes17(byte[] value) {
    super(17, value);
  }
}
