package org.web3j.abi.datatypes.generated;

import org.web3j.abi.datatypes.Bytes;

/**
 * <p>Auto generated code.<br>
 * <strong>Do not modifiy!</strong><br>
 * Please use {@link org.web3j.codegen.AbiTypesGenerator} to update.</p>
 */
public class Bytes5 extends Bytes {
  public static final Bytes5 DEFAULT = new Bytes5(new byte[5]);

  public Bytes5(byte[] value) {
    super(5, value);
  }
}
