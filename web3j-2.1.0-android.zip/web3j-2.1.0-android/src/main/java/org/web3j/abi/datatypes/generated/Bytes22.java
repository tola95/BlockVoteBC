package org.web3j.abi.datatypes.generated;

import org.web3j.abi.datatypes.Bytes;

/**
 * <p>Auto generated code.<br>
 * <strong>Do not modifiy!</strong><br>
 * Please use {@link org.web3j.codegen.AbiTypesGenerator} to update.</p>
 */
public class Bytes22 extends Bytes {
  public static final Bytes22 DEFAULT = new Bytes22(new byte[22]);

  public Bytes22(byte[] value) {
    super(22, value);
  }
}
