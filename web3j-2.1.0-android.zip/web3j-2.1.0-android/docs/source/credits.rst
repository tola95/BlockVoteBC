Thanks and Credits
==================

- The `Nethereum <https://github.com/Nethereum/Nethereum>`_ project for the inspiration
- `Othera <https://www.othera.com.au/>`_ for the great things they are building on the platform
- `Finhaus <http://finhaus.com.au/>`_ guys for putting me onto Nethereum
- `bitcoinj <https://bitcoinj.github.io/>`_ for the reference Elliptic Curve crypto implementation
- Everyone involved in the Ethererum project and its surrounding ecosystem
- And of course the users of the library, who've provided valuable input & feedback -
  `@ice09 <https://github.com/ice09>`_, `@adridadou <https://github.com/adridadou>`_,
  `@nickmelis <https://github.com/nickmelis>`_, `@basavk <https://github.com/basavk>`_,
  `@kabl <https://github.com/kabl>`_, `@MaxBinnewies <https://github.com/MaxBinnewies>`_,
  `@vikulin <https://github.com/vikulin>`_, `@sullis <https://github.com/sullis>`_,
  `@vethan <https://github.com/vethan>`_, `@h2mch <https://github.com/h2mch>`_,
  `@mtiutin <https://github.com/mtiutin>`_, `@fooock <https://github.com/fooock>`_,
  `@ermyas <https://github.com/ermyas>`_, `@danieldietrich <https://github.com/danieldietrich>`_,
  `@matthiaszimmermann <https://github.com/matthiaszimmermann>`_,
  `@ferOnti <https://github.com/ferOnti>`_, `@fraspadafora <https://github.com/fraspadafora>`_,
  `@bigstar119 <https://github.com/bigstar119>`_, `@gagarin55 <https://github.com/gagarin55>`_,
  `@thedoctor <https://github.com/thedoctor>`_, `@tramonex-nate <https://github.com/tramonex-nate>`_,
  `@ferOnti <https://github.com/ferOnti>`_
