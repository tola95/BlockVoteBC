package org.web3j.abi.datatypes.generated;

import org.web3j.abi.datatypes.Bytes;

/**
 * <p>Auto generated code.<br>
 * <strong>Do not modifiy!</strong><br>
 * Please use {@link org.web3j.codegen.AbiTypesGenerator} to update.</p>
 */
public class Bytes10 extends Bytes {
  public static final Bytes10 DEFAULT = new Bytes10(new byte[10]);

  public Bytes10(byte[] value) {
    super(10, value);
  }
}
