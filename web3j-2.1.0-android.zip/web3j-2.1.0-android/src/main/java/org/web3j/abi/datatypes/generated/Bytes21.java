package org.web3j.abi.datatypes.generated;

import org.web3j.abi.datatypes.Bytes;

/**
 * <p>Auto generated code.<br>
 * <strong>Do not modifiy!</strong><br>
 * Please use {@link org.web3j.codegen.AbiTypesGenerator} to update.</p>
 */
public class Bytes21 extends Bytes {
  public static final Bytes21 DEFAULT = new Bytes21(new byte[21]);

  public Bytes21(byte[] value) {
    super(21, value);
  }
}
