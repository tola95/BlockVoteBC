package org.web3j.abi.datatypes.generated;

import org.web3j.abi.datatypes.Bytes;

/**
 * <p>Auto generated code.<br>
 * <strong>Do not modifiy!</strong><br>
 * Please use {@link org.web3j.codegen.AbiTypesGenerator} to update.</p>
 */
public class Bytes2 extends Bytes {
  public static final Bytes2 DEFAULT = new Bytes2(new byte[2]);

  public Bytes2(byte[] value) {
    super(2, value);
  }
}
